# initiating list, variables etc.
all_rooms = [101,102,103,104,201,202,203,204,301,302,303,304,401,402,403,404]

floor1 = [1,1,2,1]

floor2 = [1,2,1,2]

floor3 = [1,2,1,2]

# method for finding available rooms
# input list, output list of positions
def find_a_rooms(floor_list):
    
    a_rooms = []
    pos = 0
    for i in range(len(floor_list)):
        if floor_list [i] == 1:
             a_rooms.append(pos)
             pos = pos + 1
        elif floor_list [i] != 1:
             pos = pos + 1
             
    return a_rooms

# method for finding occupied rooms
# input list, output list of positions
def find_o_rooms(floor_list):
    
    a_rooms = []
    pos = 0
    for i in range(len(floor_list)):
        if floor_list [i] == 2:
             a_rooms.append(pos)
             pos = pos + 1
        elif floor_list [i] != 2:
             pos = pos + 1
             
    return a_rooms    

# method for finding occupied rooms
# input list, output list of positions
def find_r_rooms(floor_list):
    
    a_rooms = []
    pos = 0
    for i in range(len(floor_list)):
        if floor_list [i] == 3:
             a_rooms.append(pos)
             pos = pos + 1
        elif floor_list [i] != 3:
             pos = pos + 1
             
    return a_rooms

# input floor, room (0-3), status (oc,av,re) - output list with new change
def change(floor,status,room):
    floor[room] = status
    return floor



def change_a_room(a):
    room_counter = 0
    error = 0
    for i in range(len(all_rooms)):
        if all_rooms[i] == a:
            break
        else:
            room_counter = room_counter + 1
            error = error + 1
        if error >= len(all_rooms):
            return "error"
    
    print('''
        2 = occupied
        3 = reserved
        ''')

    input_change = int(input("change to : "))

    if input_change != 2 and input_change != 3:
        return "error"

    if room_counter < 4:
        if floor1[room_counter] == 1:
             a = change(floor1, input_change, room_counter)
             return a
        else:
             return "error"

    elif room_counter < 8:
        room_counter = room_counter - 4
        if floor2[room_counter] == 2:
             a = change(floor2, input_change, room_counter)
             return a
        else:
            return "error"
    else:
        room_counter = room_counter - 8
        if floor3[room_counter] == 1:
             a =change(floor3, input_change, room_counter)
             return a
        else:
            return "error"


def change_o_room(a):
    room_counter = 0
    error = 0
    for i in range(len(all_rooms)):
        if all_rooms[i] == a:
            break
        else:
            room_counter = room_counter + 1
            error = error + 1
        if error >= len(all_rooms):
            return "error"
    
    print('''
        1 = available
        3 = reserved
        ''')
    input_change = int(input("change to : "))

    if input_change != 1 and input_change != 3:
        return "error"

    if room_counter < 4:
        if floor1[room_counter] == 2:
             a = change(floor1, input_change, room_counter)
             return a
        else:
            return "error"

    elif room_counter < 8:
        room_counter = room_counter - 4
        if floor2[room_counter] == 2:
             a = change(floor2, input_change, room_counter)
             return a
        else:
            return "error"
    else:
        room_counter = room_counter - 8
        if floor3[room_counter] == 2:
             a =change(floor3, input_change, room_counter)
             return a
        else:
             return "error"



#def change_r_room():       incomming object                                                                                                                                                                                                                                                                                                                                           


a = find_a_rooms(floor1)
b = find_o_rooms(floor2)
c = find_a_rooms(floor3)
 


print(a)
print(b)
print(c)

new_floor = change_a_room(int(input("enter the room number: ")))

print(new_floor)
