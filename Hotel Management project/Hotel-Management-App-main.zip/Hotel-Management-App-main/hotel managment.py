available = [101, 102, 103, 104, 201, 202, 203, 204, 301, 302, 303, 304]
occupied = []
reserved = []

# all functions that change room states

def change_available_to_occupied(room):
    available.remove(room)
    occupied.append(room)

def change_occupied_to_available(room):
    occupied.remove(room)
    available.append(room)

def change_available_to_reserved(room):
    available.remove(room)
    reserved.append(room)

def change_reserved_to_available(room):
    reserved.remove(room)
    available.append(room)

def change_reserved_to_occupied(room):
    reserved.remove(room)
    occupied.append(room)
    

        
 hotel_file  = open("data_save.txt", "r")
 available_file= hotel_file.readline().split(",")
 occupied_file = hotel_file.readline().split(",")
 reserved_file = hotel_file.readline().split(",")
 print(available_file)
 print(occupied_file)
 print(reserved_file)
 hotel_file.close()
 hotel_file  = open("data_save.txt", "w")
 hotel_file.write(str(available) + "\n")
 hotel_file.write(str(occupied) + "\n")
 hotel_file.write(str(reserved) + "\n")
 hotel_file.close()

