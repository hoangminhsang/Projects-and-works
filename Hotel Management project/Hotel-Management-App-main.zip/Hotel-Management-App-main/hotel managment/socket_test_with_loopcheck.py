import socket
import time



socket_server_test = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
port = 10001
socket_server_test.bind(("", port))
socket_server_test.listen(5)


while True:

    client_socket, client_address = socket_server_test.accept()

    print(f"connection from {client_address} has been established")

    while True:
        time.sleep(20)

        hotel_test_file = open("data_save.txt", "r")

        available_check = hotel_test_file.readline()
        occupied_check = hotel_test_file.readline()
        reserved_check  = hotel_test_file.readline()
     
        hotel_test_file.close()

        print(str(available_check + occupied_check + reserved_check))

        client_socket.send(bytes(str(available_check + occupied_check + reserved_check),"utf-8"))
















