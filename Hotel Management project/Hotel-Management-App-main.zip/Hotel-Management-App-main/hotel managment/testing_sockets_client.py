from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
import sys
import socket


# socket stuff

#socket_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#socket_client.connect(("10.10.0.55", 10001))

#while True:
#    try:
#        message1 = socket_client.recv(1024)
#        text_receive = message1.decode("utf-8")
#        text_data = open("client_data.txt", "w")

#        text_data.write(text_receive)
#
#        text_data.close()

#        print(text_receive)

#        break

#    except:
#        pass



# GUI part

list_button_client = ["101","102","103","104","201","202","203","204","301","302","303","304"]
hotel_file_r  = open("client_data.txt", "r")
available = hotel_file_r.readline().split(",")
occupied = hotel_file_r.readline().split(",")
reserved  = hotel_file_r.readline().split(",")
available.pop() 
occupied.pop()
reserved.pop()
hotel_file_r.close()

def client_window():


    app = QApplication(sys.argv)
    global window_client
    window_client = QMainWindow()
    window_client.setGeometry(200, 200, 450, 500)
    window_client.setWindowTitle("hotel client")

    for i in range(3):
        for j in range(4):
            create_button(j,i)
    for a in range(len(available)):
        list_button_client[room_number_converter(available[a])].setStyleSheet("background-color:rgb(0,255,128)")

    for o in range(len(occupied)):
        list_button_client[room_number_converter(occupied[o])].setStyleSheet("background-color:rgb(255,102,102)")

    for r in range(len(reserved)):
        list_button_client[room_number_converter(reserved[r])].setStyleSheet("background-color:rgb(255,255,102)")


    list_button_client[0].setText("101")
    list_button_client[1].setText("102")
    list_button_client[2].setText("103")
    list_button_client[3].setText("104")
    list_button_client[4].setText("201")
    list_button_client[5].setText("202")
    list_button_client[6].setText("203")
    list_button_client[7].setText("204")
    list_button_client[8].setText("301")
    list_button_client[9].setText("302")
    list_button_client[10].setText("303")
    list_button_client[11].setText("304")

    list_button_client[0].clicked.connect(button_clicked0)
    list_button_client[1].clicked.connect(button_clicked1)
    list_button_client[2].clicked.connect(button_clicked2)
    list_button_client[3].clicked.connect(button_clicked3)
    list_button_client[4].clicked.connect(button_clicked4)
    list_button_client[5].clicked.connect(button_clicked5)
    list_button_client[6].clicked.connect(button_clicked6)
    list_button_client[7].clicked.connect(button_clicked7)
    list_button_client[8].clicked.connect(button_clicked8)
    list_button_client[9].clicked.connect(button_clicked9)
    list_button_client[10].clicked.connect(button_clicked10)
    list_button_client[11].clicked.connect(button_clicked11)

    global booking_button
    booking_button = QtWidgets.QPushButton(window_client)
    booking_button.setText("booking")
    booking_button.setGeometry(20, 250, 100, 25)
    booking_button.clicked.connect(booking_clicked)
    for a in range(len(available)):
        list_button_client[room_number_converter(available[a])].setStyleSheet("background-color:rgb(0,255,128)")

    for o in range(len(occupied)):
        list_button_client[room_number_converter(occupied[o])].setStyleSheet("background-color:rgb(255,102,102)")
        list_button_client[room_number_converter(occupied[o])].setEnabled(False)


    for r in range(len(reserved)):
        list_button_client[room_number_converter(reserved[r])].setStyleSheet("background-color:rgb(255,255,102)")
        list_button_client[room_number_converter(reserved[r])].setEnabled(False)


    window_client.show()
    sys.exit(app.exec())





def create_button(j,i):
    list_button_client[4 * i + j] = QtWidgets.QPushButton(window_client)
    list_button_client[4 * i + j].move(100 * j, 75 * i + 25)


def room_number_converter(room_number):
    room_number = int(room_number)
    if room_number < 150:
        room_number = room_number - 101
        return room_number
    if room_number < 250:
        room_number = room_number - 197
        return room_number
    if room_number < 350:
        room_number = room_number - 293
        return room_number  



def booking_clicked():
    pass


def button_clicked0():
    change_available_to_reserved("101")
    

     
def button_clicked1():
    change_available_to_reserved("102")
    
def button_clicked2():
    change_available_to_reserved("103")
    
def button_clicked3():
    change_available_to_reserved("104")
    
def button_clicked4():
    change_available_to_reserved("201")
    
def button_clicked5():
    change_available_to_reserved("202")
    
def button_clicked6():
    change_available_to_reserved("203")
   
def button_clicked7():
    change_available_to_reserved("204")
    
def button_clicked8():
    change_available_to_reserved("301")
def button_clicked9():
    change_available_to_reserved("302")
def button_clicked10():
    change_available_to_reserved("303")
def button_clicked11():
    change_available_to_reserved("304")
def change_available_to_reserved(room):
    available.remove(room)
    reserved.append(room)
    room_pos = room_number_converter(room)
    list_button_client[room_pos].setStyleSheet("background-color:rgb(255,255,102)")




client_window()






