import socket

socket_hotel = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

port = 10000
socket_hotel.bind((socket.gethostname(),port))
socket_hotel.listen(2)

while True:
    client_socket, client_address = socket_hotel.accept()
    print(f"connection from {client_address} has been established")
    client_socket.send(bytes("welcome to the server", "utf-8"))
    client_socket.send(bytes("you suck", "utf-8"))

    message = client_socket.recv(1024)
    print(message.decode("utf-8"))






