import socket

socket_hotel = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket_hotel.connect((socket.gethostname(), 10000))

message = socket_hotel.recv(1024)
print(message.decode("utf-8"))



"""
socket_hotel.send(bytes("you suck", "utf-8"))


message = socket_hotel.recv(1024)
print(message.decode("utf-8"))
"""



