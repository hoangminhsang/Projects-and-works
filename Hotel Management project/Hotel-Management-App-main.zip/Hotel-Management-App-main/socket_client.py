import socket
import time
host = socket.gethostbyname(socket.gethostname())
port = 9999



client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#Connecting to the server
client.connect((host, port))

#Opening and reading the file data. 
while True:
    file = open("data_save.txt", "r")
    data = file.read()

#Sending the filename to the server. 
    client.send("data_save.txt".encode("utf-8"))
    msg = client.recv(1024).decode("utf-8")
    print(f"[SERVER]: {msg}")

#Sending the file data to the server.
    client.send(data.encode("utf-8"))
    msg = client.recv(1024).decode("utf-8")
    print(f"[SERVER]: {msg}")

#Closing the file. 
    file.close()



