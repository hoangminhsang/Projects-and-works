import socket
host = socket.gethostbyname(socket.gethostname())
port = 9999


print("[STARTING] Server is starting.")
#Staring a TCP socket.
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#Bind the IP and PORT to the server.
server.bind((host, port))

#Server is listening, i.e., server is now waiting for the client to connected.
server.listen()
print("[LISTENING] Server is listening.")


#Server has accepted the connection from the client
conn, addr = server.accept()
print(f"[NEW CONNECTION] {addr} connected.")

    #Receiving the filename from the client
while True:
    filename = conn.recv(1024).decode("utf-8")
    print(f"[RECV] Receiving the filename.")
    file = open(filename, "w")
    conn.send("Filename received.".encode("utf-8"))

    #Receiving the file data from the client
    data = conn.recv(1024).decode("utf-8")
    print(f"[RECV] Receiving the file data.")
    file.write(data)
    conn.send("File data received".encode("utf-8"))

    #Closing the file.
    file.close()
        


