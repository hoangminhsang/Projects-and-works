from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
import sys

# getting data from file
hotel_file_r  = open("data_save.txt", "r")
available = hotel_file_r.readline().split(",")
occupied = hotel_file_r.readline().split(",")
reserved  = hotel_file_r.readline().split(",")
available.pop() 
occupied.pop()
reserved.pop()
hotel_file_r.close()

print(available)
print(occupied)
print(reserved)

# buttons section

list_buttons = ["101","102","103","104","201","202","203","204","301","302","303","304"]


# everything about the window
def window ():
    app = QApplication(sys.argv)
    global win
    win = QMainWindow()
    win.setGeometry(200, 200, 450, 500)
    win.setWindowTitle("hotel management")

    # button creation

    for i in range(3):
        for j in range(4):
            create_button(j,i)

    # three floor labels

    label1 = QtWidgets.QLabel(win)
    label1.setText("Floor 1")
    label1.move(180,0)
    label2 = QtWidgets.QLabel(win)
    label2.setText("Floor 2")
    label2.move(180,75)
    label3 = QtWidgets.QLabel(win)
    label3.setText("Floor 3")
    label3.move(180,150)

    hallway1 = QtWidgets.QPushButton(win)
    hallway1.setText("Hallway")
    hallway1.setGeometry(0, 54, 400, 25)
    hallway1.setEnabled(False)

    hallway2 = QtWidgets.QPushButton(win)
    hallway2.setText("Hallway")
    hallway2.setGeometry(0, 129, 400, 25)
    hallway2.setEnabled(False)

    hallway3 = QtWidgets.QPushButton(win)
    hallway3.setText("Hallway")
    hallway3.setGeometry(0, 204, 400, 25)
    hallway3.setEnabled(False)

    elevator = QtWidgets.QPushButton(win)
    elevator.setText("elev")
    elevator.setGeometry(400, 25, 50, 200)
    elevator.setEnabled(False)
    elevator.setStyleSheet("background-color:rgb(204,255,255)")

    global available_button
    available_button = QtWidgets.QPushButton(win)
    available_button.setText("available")
    available_button.setGeometry(20, 250, 100, 25)
    available_button.clicked.connect(available_button_clicked)

    global occupied_button
    occupied_button = QtWidgets.QPushButton(win)
    occupied_button.setText("occupied")
    occupied_button.setGeometry(20, 280, 100, 25)
    occupied_button.clicked.connect(occupied_button_clicked)

    global reserved_button
    reserved_button = QtWidgets.QPushButton(win)
    reserved_button.setText("reverved")
    reserved_button.setGeometry(20, 310, 100, 25)
    reserved_button.clicked.connect(reserved_button_clicked)

    save_button = QtWidgets.QPushButton(win)
    save_button.setText("save")
    save_button.setGeometry(300, 310, 100, 25)
    save_button.clicked.connect(save_button_clicked)


    # initial state of the rooms

    for a in range(len(available)):
        list_buttons[room_number_converter(available[a])].setStyleSheet("background-color:rgb(0,255,128)")

    for o in range(len(occupied)):
        list_buttons[room_number_converter(occupied[o])].setStyleSheet("background-color:rgb(255,102,102)")

    for r in range(len(reserved)):
        list_buttons[room_number_converter(reserved[r])].setStyleSheet("background-color:rgb(255,255,102)")

    # button text

    list_buttons[0].setText("101")
    list_buttons[1].setText("102")
    list_buttons[2].setText("103")
    list_buttons[3].setText("104")
    list_buttons[4].setText("201")
    list_buttons[5].setText("202")
    list_buttons[6].setText("203")
    list_buttons[7].setText("204")
    list_buttons[8].setText("301")
    list_buttons[9].setText("302")
    list_buttons[10].setText("303")
    list_buttons[11].setText("304")

    # button connector to function

    list_buttons[0].clicked.connect(button_clicked0)
    list_buttons[1].clicked.connect(button_clicked1)
    list_buttons[2].clicked.connect(button_clicked2)
    list_buttons[3].clicked.connect(button_clicked3)
    list_buttons[4].clicked.connect(button_clicked4)
    list_buttons[5].clicked.connect(button_clicked5)
    list_buttons[6].clicked.connect(button_clicked6)
    list_buttons[7].clicked.connect(button_clicked7)
    list_buttons[8].clicked.connect(button_clicked8)
    list_buttons[9].clicked.connect(button_clicked9)
    list_buttons[10].clicked.connect(button_clicked10)
    list_buttons[11].clicked.connect(button_clicked11)

    win.show()
    sys.exit(app.exec())
    
# function that creates buttons

def create_button(j,i):
    list_buttons[4 * i + j] = QtWidgets.QPushButton(win)
    list_buttons[4 * i + j].move(100 * j, 75 * i + 25)

# converts room number into its position on lits_buttons

def room_number_converter(room_number):
    room_number = int(room_number)
    if room_number < 150:
        room_number = room_number - 101
        return room_number
    if room_number < 250:
        room_number = room_number - 197
        return room_number
    if room_number < 350:
        room_number = room_number - 293
        return room_number

# searching for the room in state list

def search_state(room):
    if room in available:
        return 1
    elif room in occupied:
        return 2
    else:
        return 3

# available, occupied and reserved buttons function

def available_button_clicked(room):
    if RAM_state == 2:
        change_occupied_to_available(RAM_room)
    elif RAM_state == 3:
        change_reserved_to_available(RAM_room)

def occupied_button_clicked():
    if RAM_state == 1:
        change_available_to_occupied(RAM_room)
    elif RAM_state == 3:
        change_reserved_to_occupied(RAM_room)

def reserved_button_clicked():
    if RAM_state == 1:
        change_available_to_reserved(RAM_room)

# disable and enable buttons

def popup_change_available(room):
    available_button.setEnabled(False)
    occupied_button.setEnabled(True)
    reserved_button.setEnabled(True)

def popup_change_occupied(room):
    available_button.setEnabled(True)
    occupied_button.setEnabled(False)
    reserved_button.setEnabled(False)

def popup_change_reserved(room):
    available_button.setEnabled(True)
    occupied_button.setEnabled(True)
    reserved_button.setEnabled(False)

# connector with also knows which state a room is

def random_connector(state,room):
    if state == 1:
        popup_change_available(room)
    elif state == 2:
        popup_change_occupied(room)
    else:
        popup_change_reserved(room)

# button clicked functions

def button_clicked0():
    global RAM_state
    global RAM_room
    RAM_state = search_state("101")
    random_connector(RAM_state,"101")
    RAM_room = "101"
def button_clicked1():
    global RAM_state
    global RAM_room
    RAM_state = search_state("102")
    random_connector(RAM_state,"102")
    RAM_room = "102"
def button_clicked2():
    global RAM_state
    global RAM_room
    RAM_state = search_state("103")
    random_connector(RAM_state,"103")
    RAM_room = "103"
def button_clicked3():
    global RAM_state
    global RAM_room
    RAM_state = search_state("104")
    random_connector(RAM_state,"104")
    RAM_room = "104"
def button_clicked4():
    global RAM_state
    global RAM_room
    RAM_state = search_state("201")
    random_connector(RAM_state,"201")
    RAM_room = "201"
def button_clicked5():
    global RAM_state
    global RAM_room
    RAM_state = search_state("202")
    random_connector(RAM_state,"202")
    RAM_room = "202"
def button_clicked6():
    global RAM_state
    global RAM_room
    RAM_state = search_state("203")
    random_connector(RAM_state,"203")
    RAM_room = "203"
def button_clicked7():
    global RAM_state
    global RAM_room
    RAM_state = search_state("204")
    random_connector(RAM_state,"204")
    RAM_room = "204"
def button_clicked8():
    global RAM_state
    global RAM_room
    RAM_state = search_state("301")
    random_connector(RAM_state,"301")
    RAM_room = "301"
def button_clicked9():
    global RAM_state
    global RAM_room
    RAM_state = search_state("302")
    random_connector(RAM_state,"302")
    RAM_room = "302"
def button_clicked10():
    global RAM_state
    global RAM_room
    RAM_state = search_state("303")
    random_connector(RAM_state,"303")
    RAM_room = "303"
def button_clicked11():
    global RAM_state
    global RAM_room
    RAM_state = search_state("304")
    random_connector(RAM_state,"304")
    RAM_room = "304"

# save buttons function

def save_button_clicked():
    save_data()


# all functions that change room states

def change_available_to_occupied(room):
    available.remove(room)
    occupied.append(room)
    room_pos = room_number_converter(room)
    list_buttons[room_pos].setStyleSheet("background-color:rgb(255,102,102)")

def change_occupied_to_available(room):
    occupied.remove(room)
    available.append(room)
    room_pos = room_number_converter(room)
    list_buttons[room_pos].setStyleSheet("background-color:rgb(0,255,128)")

def change_available_to_reserved(room):
    available.remove(room)
    reserved.append(room)
    room_pos = room_number_converter(room)
    list_buttons[room_pos].setStyleSheet("background-color:rgb(255,255,102)")

def change_reserved_to_available(room):
    reserved.remove(room)
    available.append(room)
    room_pos = room_number_converter(room)
    list_buttons[room_pos].setStyleSheet("background-color:rgb(0,255,128)")

def change_reserved_to_occupied(room):
    reserved.remove(room)
    occupied.append(room)
    room_pos = room_number_converter(room)
    list_buttons[room_pos].setStyleSheet("background-color:rgb(255,102,102)")

# saving data to file

def save_data():
    
    hotel_file_w  = open("data_save.txt", "w")
    
    for i in range(len(available)):
      hotel_file_w.writelines((available[i] + ","))

    hotel_file_w.write("\n")

    for i in range(len(occupied)):
        hotel_file_w.writelines((occupied[i] + ","))
    
    hotel_file_w.write("\n")
    
    for i in range(len(reserved)):
        hotel_file_w.writelines((reserved[i] + ","))
    
    hotel_file_w.close()


while True:
    window()
