from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow
import sys

list = ["button_101","button_102","room_103","room_104"]

def window ():
    app = QApplication(sys.argv)
    global win
    win = QMainWindow()
    win.setGeometry(200, 200, 400, 500)
    win.setWindowTitle("hotel management")


    for i in range(4):
        create_button(i)

    
    list[0].clicked.connect(button_clicked0)
    list[1].clicked.connect(button_clicked1)
    list[2].clicked.connect(button_clicked2)
    list[3].clicked.connect(button_clicked3)


    win.show()
    sys.exit(app.exec())


def create_button(button):
    list[button] = QtWidgets.QPushButton(win)
    list[button].move(100*button,0)





def button_clicked0():
    list[0].setStyleSheet("background-color : yellow")

def button_clicked1():
    list[1].setStyleSheet("background-color : yellow")

def button_clicked2():
    list[2].setStyleSheet("background-color : yellow")

def button_clicked3():
    list[3].setStyleSheet("background-color : yellow")


window()
